import TiCameraView from 'ti.cameraview';
Alloy.Globals.CAMERA_LIST = TiCameraView.cameraList;
Ti.API.info('** Alloy = ' + JSON.stringify(Alloy.Globals.CAMERA_LIST));

Alloy.Globals.CAMERA_LIST = Alloy.Globals.CAMERA_LIST.map( (item) => {
    return {
        name: item.cameraType,
        value: item.cameraId
    };
});

/*
[
    {
        "cameraId": 0,
        "cameraType": "CAMERA_TYPE_BACK"
    },
    {
        "cameraId": 1,
        "cameraType": "CAMERA_TYPE_FRONT"
    }
];
*/
