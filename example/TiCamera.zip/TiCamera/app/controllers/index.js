import TiCameraView from 'ti.cameraview';

const TORCH_MODES = [
    {name: 'TORCH_MODE_OFF', value: TiCameraView.TORCH_MODE_OFF},
    {name: 'TORCH_MODE_ON', value: TiCameraView.TORCH_MODE_ON}
];
const FLASH_MODES = [
    {name: 'FLASH_MODE_AUTO', value: TiCameraView.FLASH_MODE_AUTO},
    {name: 'FLASH_MODE_ON', value: TiCameraView.FLASH_MODE_ON},
    {name: 'FLASH_MODE_OFF', value: TiCameraView.FLASH_MODE_OFF}
];
const ASPECT_RATIOS = [
    {name: 'ASPECT_RATIO_4_3', value: TiCameraView.ASPECT_RATIO_4_3},
    {name: 'ASPECT_RATIO_16_9', value: TiCameraView.ASPECT_RATIO_16_9}
];
const SCALE_TYPES = [
    {name: 'FIT_CENTER', value: TiCameraView.SCALE_TYPE_FIT_CENTER},
    {name: 'FILL_CENTER', value: TiCameraView.SCALE_TYPE_FILL_CENTER}
];
const FOCUS_MODES = [
    {name: 'FOCUS_MODE_AUTO', value: TiCameraView.FOCUS_MODE_AUTO},
    {name: 'FOCUS_MODE_TAP', value: TiCameraView.FOCUS_MODE_TAP}
];
const QUALITY_MODES = [
    {name: 'QUALITY_NORMAL', value: TiCameraView.IMAGE_QUALITY_NORMAL},
    {name: 'QUALITY_HIGH', value: TiCameraView.IMAGE_QUALITY_HIGH}
];
const RESUME_AUTO_FOCUS = [
    {name: 'RESUME_TRUE', value: true},
    {name: 'RESUME_FALSE', value: false}
];

let cameraView = null;


(function () {
    $.index.open();
}())


function checkPermissions(e){
    if (Ti.Media.hasCameraPermissions()) {
        addCameraView();
    } else {
        Ti.Media.requestCameraPermissions(result => result.success ? addCameraView() : alert('Camera permissions required'));
    }
}

function addCameraView() {
    if (!Ti.Media.hasCameraPermissions()) {
        Ti.API.info('** camera permissions required…');
        return;
    }

    try {
        cameraView = TiCameraView.createCameraView({
            top: 16,
            left: 16,
            right: 16,
            height: 300,
            backgroundColor: '#cccccc',
            lifecycleContainer: $.getView()
        });

        $.index.add(cameraView);

        setLabels(0);

        $.cardView.show({animate: true});

    } catch (exc) {
        cameraView = null;
    }
}

function handleMenuClick(e) {
    if (cameraView == null) return

    const id = e.source.id;
    let index = 0;

    if (id === 'menu1') {
        getNextValueFromList(TORCH_MODES, 'torchMode');

    } else if (id === 'menu2') {
        index = getNextValueFromList(FLASH_MODES, 'flashMode');
        $.label2.text = FLASH_MODES[index].name;

    } else if (id === 'menu3') {
        index = getNextValueFromList(ASPECT_RATIOS, 'aspectRatio');
        $.label3.text = ASPECT_RATIOS[index].name;

    } else if (id === 'menu4') {
        index = getNextValueFromList(SCALE_TYPES, 'scaleType');
        $.label4.text = SCALE_TYPES[index].name;

    } else if (id === 'menu5') {
        index = getNextValueFromList(FOCUS_MODES, 'focusMode');
        $.label5.text = FOCUS_MODES[index].name;

    } else if (id === 'menu6') {
        index = getNextValueFromList(RESUME_AUTO_FOCUS, 'resumeAutoFocus');
        $.label6.text = RESUME_AUTO_FOCUS[index].name;

    } else if (id === 'menu7') {
        getNextValueFromList(Alloy.Globals.CAMERA_LIST, 'cameraId');

    } else if (id === 'menu8') {
        index = getNextValueFromList(QUALITY_MODES, 'imageQuality');
        $.label8.text = QUALITY_MODES[index].name;
    }
}

function getNextValueFromList(list, cameraProperty) {
    let currentValueIndex = -1;

    for (let i = 0; i < list.length; i++) {
        if (list[i].value == cameraView[cameraProperty]) {
            currentValueIndex = i;
            break;
        }
    }

    ++currentValueIndex;

    // reset the index if last index was found
    if (currentValueIndex >= list.length) {
        currentValueIndex = 0;
    }

    cameraView[cameraProperty] = list[currentValueIndex].value;

    return currentValueIndex;
}

function setLabels(index) {
    $.label2.text = FLASH_MODES[index].name;
    $.label3.text = ASPECT_RATIOS[index].name;
    $.label4.text = SCALE_TYPES[index].name;
    $.label5.text = FOCUS_MODES[index].name;
    $.label6.text = RESUME_AUTO_FOCUS[index].name;
    $.label8.text = QUALITY_MODES[index].name;
}

function showCameraList(e){
    alert("******** Camera List ********\n\n" + JSON.stringify(TiCameraView.cameraList));
}

function capturePhoto(e){
    if (cameraView == null) {
        alert('camera-view not available');
        return
    }

    $.cardView.animate({
        duration: 125,
        transform: Ti.UI.create2DMatrix({scale: 1.2}),
        autoreverse: true
    });

    const progressIndicator = Ti.UI.Android.createProgressIndicator({
        message: 'Processing...',
        location: Ti.UI.Android.PROGRESS_INDICATOR_DIALOG,
        type: Ti.UI.Android.PROGRESS_INDICATOR_INDETERMINANT,
        cancelable: false,
        min: 0,
        max: 10
    });

    progressIndicator.show();

    cameraView.capturePhoto({
        callback: function (result) {
            setTimeout(function () {
                progressIndicator.hide();
            }, 2000)

            if (result.success) {
                let imageBlob = result.image;

                // center crop image if scale-type is fill
                if (cameraView.scaleType === TiCameraView.SCALE_TYPE_FILL_CENTER) {
                    const minCropDimension = Math.min(imageBlob.width, imageBlob.height);

                    imageBlob = imageBlob.imageAsCropped({
                        width: minCropDimension,
                        height: minCropDimension
                    });
                }

                Alloy.createController('photo', {
                    image: imageBlob
                }).getView().open()

                setTimeout(function () {
                    let msg = '******* Picture Details ******* \n'
                    msg += '\nImage width:  ' + imageBlob.width;
                    msg += '\nImage height:  ' + imageBlob.height;
                    msg += '\nImage size:  ' + parseFloat(imageBlob.length/1024/1024).toFixed(1) + ' MB';
                    msg += '\nImage mega-pixel:  ' + Math.ceil(imageBlob.size/1000000) + ' MP';
                    alert(msg);
                }, 1000)
            } else {
                alert(result.message);
            }
        }
    });
}
