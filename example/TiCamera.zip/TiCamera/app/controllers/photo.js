import TiTouchImageView from 'org.iotashan.TiTouchImageView';

const myView = TiTouchImageView.createView({
    image: $.args.image,
    maxZoom: 5,
    minZoom: 1
});

$.getView().add(myView);

function close(e){
    $.getView().close();
}
